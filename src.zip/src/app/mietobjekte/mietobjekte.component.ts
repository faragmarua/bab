import { Component } from '@angular/core';

@Component({
  selector: 'app-mietobjekte',
  templateUrl: './mietobjekte.component.html',
  styleUrls: ['./mietobjekte.component.css']
})
export class MietobjekteComponent {

}
